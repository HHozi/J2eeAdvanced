package com.snailclimb.dao;

import java.util.List;

import com.snailclimb.bean.User;

public interface UserMapper {
	public List<User> selecAgreesTop10();
}
