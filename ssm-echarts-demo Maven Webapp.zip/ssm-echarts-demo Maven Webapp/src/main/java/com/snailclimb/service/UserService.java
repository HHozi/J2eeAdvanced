package com.snailclimb.service;

import java.util.List;

import com.snailclimb.bean.User;

public interface UserService {
	public List<User> selecAgreesTop10();
}
