package utils;

import java.io.IOException;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

/**
 * 发送邮件的工具类
 * 
 * @author Snailclimb
 *
 */
public class EmailUtils {
	/**
	 * 
	 * @param text
	 *            要发送的内容
	 * @param emailAdress
	 *            要发送的邮件地址
	 * @param javaMailSender
	 * @return
	 */
	public Object sendMail(String text, String emailAdress, JavaMailSender javaMailSender) {
		MimeMessage mMessage = javaMailSender.createMimeMessage();// 创建邮件对象
		MimeMessageHelper mMessageHelper;
		Properties prop = new Properties();
		String from;
		try {
			// 从配置文件中拿到发件人邮箱地址
			prop.load(this.getClass().getResourceAsStream("/mail.properties"));
			from = prop.get("mail.smtp.username") + "";
			mMessageHelper = new MimeMessageHelper(mMessage, true);
			mMessageHelper.setFrom(from);// 发件人邮箱
			mMessageHelper.setTo(emailAdress);// 收件人邮箱
			mMessageHelper.setSubject("邮件主题Spring的邮件发送");// 邮件的主题
			// 邮件的文本内容，true表示文本以html格式打开
			mMessageHelper.setText(text, false);
			javaMailSender.send(mMessage);// 发送邮件
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "发送成功";
	}
}
